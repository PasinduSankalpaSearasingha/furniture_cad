# Edit parameters.json, then run with the project .venv.
import runpy,json
from pathlib import Path
folder=Path(__file__).resolve().parent
context=runpy.run_path(str(folder.parents[1]/'assembly.py'))
from app.photo_schema import PhotoPart,PhotoDesign
from app.mesh_to_cad import build_native
import cadquery as cq
data=json.loads((folder/'parameters.json').read_text(encoding='utf-8'));plan=context['plan']
replacement=PhotoPart.model_validate(data['part'])
for index,part in enumerate(plan.parts):
    if part.part_id==replacement.part_id:plan.parts[index]=replacement
values={v['key']:v['value'] for v in data['values']}
for value in plan.values:
    if value.key in values:value.value=values[value.key]
plan=PhotoDesign.model_validate(plan.model_dump());build=build_native(plan)
cq.exporters.export(build.local_shapes['F001'],str(folder/'edited_part.step'))
